package Assignment1;



/*
 * Romin Patel
 * 3164066
 * Assignment-1
 * ACS-2947
 */
public class Assign1PartA_Driver {
    public static void main(String[] args) {
        courseWaitList cw = new courseWaitList();
        cw.simulate();
    }
}
