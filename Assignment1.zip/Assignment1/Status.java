package Assignment1;



/*
 * Romin Patel
 * 3164066
 * Assignment-1
 * ACS-2947
 */
public enum Status {
WAITLISTED, PERMITTEDTOREGISTER;
}
